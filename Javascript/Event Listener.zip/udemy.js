var button = document.getElementsByTagName("button")[0]
button.addEventListener("click", function () {
    console.log("Click!!");
})